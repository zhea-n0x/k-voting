<?php $__env->startSection('body'); ?>
<style>
    table.dataTable tbody th, table.dataTable tbody td {
    padding: 8px 10px !important; /* e.g. change 8x to 4px here */
}
</style>
    <center>
        <div class="container px-16 mt-6">
            
            <a href="/privileged_admin/add_dlm" class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 mb-5">
                <i class="fas fa-plus"></i>  Tambah Calon
            </a>
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>No. Urut</th>
                        <th>Pasangan</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dlm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="pb-10 text-center"><?php echo e($b->no_urut); ?></td>
                            <td class="pb-10"><?php echo e($b->name); ?></td>
                            <td class="pb-10">
                                
                                <a href="/privileged_admin/detail_dlm/<?php echo e($b->id); ?>" class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                  <i class="fas fa-eye"></i>  Detail
                                </a>
                                <a href="/privileged_admin/delete_dlm/<?php echo e($b->id); ?>" class="mt-3 block text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center ">
                                  <i class="fas fa-times"></i>  Hapus
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </center>

    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                fixedColumns:   {
                    heightMatch: 'none'
                }
            });
        });


    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user.u_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project-External\k_voting\resources\views/Pages/user/data_dlm.blade.php ENDPATH**/ ?>