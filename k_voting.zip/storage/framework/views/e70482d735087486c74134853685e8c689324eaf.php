<?php $__env->startSection('body'); ?>
<style>
    table.dataTable tbody th, table.dataTable tbody td {
    padding: 8px 10px !important; /* e.g. change 8x to 4px here */
}
</style>
    <center>
        <div class="container px-36 mt-6">
            
            <form action="<?php echo e(route("privileged_admin/edit_dlm/")); ?>" method="POST" class="flex flex-col gap-3" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                
                <center>
                    <img src="/uploads/dlm/<?php echo e($dlm->photo); ?>" class="w-56 items-center" alt="" srcset="">
                </center>
                
                <input type="hidden" value="<?php echo e($dlm->id); ?>" name="id">
                <div class="flex flex-col gap-3">
                    <label for="" class="text-left">Foto Calon</label>
                    <input type="file" class="w-full rounded-md" name="image">
                </div>
                <div class="flex flex-col gap-3">
                    <label for="" class="text-left">No. Urut</label>
                    <input type="text" value="<?php echo e($dlm->no_urut); ?>" class="w-full rounded-md" name="no_urut">
                </div>

                <div class="flex flex-col gap-3">
                    <label for="" class="text-left">Nama Calon</label>
                    <input type="text" value="<?php echo e($dlm->name); ?>" class="w-full rounded-md" name="name">
                </div>
                <div class="flex flex-col gap-3">
                    <label for="" class="text-left">Program Studi</label>
                    <input type="text" value="<?php echo e($dlm->study_program); ?>" class="w-full rounded-md" name="study_program">
                </div>
                <div class="flex flex-col gap-3">
                    <label for="" class="text-left">Visi</label>
                    <textarea name="visi" class="rounded-md"><?php echo e($dlm->visi); ?></textarea>
                </div>
                <div class="flex flex-col gap-3">
                    <label for="" class="text-left">Misi</label>
                    <textarea name="misi" class="rounded-md"><?php echo e($dlm->misi); ?></textarea>
                </div>
                
                <div class="flex flex-col gap-3">
                    <button type="submit" class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                         Submit <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </form>
            


        </div>
    </center>
        <script type="text/javascript">
            tinymce.init({
                selector: 'textarea#tiny'
            });
        </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user.u_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project-External\k_voting\resources\views/Pages/user/data_dlm_detail.blade.php ENDPATH**/ ?>