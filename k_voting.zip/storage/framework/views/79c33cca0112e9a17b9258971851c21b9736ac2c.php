    <?php $__env->startSection('wrapper'); ?>
    
                
                
    <div class="lg:flex">
        <div class="max-w-screen-sm -ml-32 lg:-ml-0 lg:w-1/2 xl:max-w-screen-sm">
            <div class="py-12 lg:bg-white flex justify-center lg:justify-start lg:px-16 lg:ml-10">
                <div class="cursor-pointer flex items-center">
                    <div>
                        <img src="<?php echo e(asset('logo.png')); ?>" alt="K-PIRA" class="w-10 h-10">
                    </div>
                    <div class="text-2xl text-red-600 tracking-wide ml-2 font-semibold">K-PIRA</div>
                </div>
            </div>
            <div class="mt-10 px-12 sm:px-24 md:px-48 lg:px-12 lg:mt-8 xl:px-24 xl:max-w-2xl">
                <p class="text-3xl font-bold tracking-wider text-red-600">Hello, There !</p>
                            <p class="text-md text-slate-500">use your e-learning identity to start session</p>
                <div class="mt-12">
                    <form action="<?php echo e(url('/auth/login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>
                            <div class="text-sm font-bold text-gray-700 tracking-wide">Username</div>
                            <input class="w-full text-lg py-2 rounded-md border-b border-gray-300 focus:outline-none focus:border-indigo-500 mt-2" type="text"  name="username" placeholder="user.33xxxxxxxx">
                        </div>
                        <div class="mt-8">
                            <div class="flex justify-between items-center">
                                <div class="text-sm font-bold text-gray-700 tracking-wide">
                                    Password
                                </div>
                            </div>
                            <input class="w-full mt-2 rounded-md text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-indigo-500" type="password" name="password" placeholder="Enter your password">
                        </div>
                        <div class="mt-10">
                            <button class="bg-red-600 text-gray-100 p-4 w-full rounded-lg tracking-wide
                            font-semibold font-display focus:outline-none focus:shadow-outline hover:bg-red-700
                            shadow-lg">
                                Log In
                            </button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
        <div class="hidden lg:flex items-center justify-center bg-custom bg-cover flex-1 h-screen">
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project-External\k_voting\resources\views/login.blade.php ENDPATH**/ ?>