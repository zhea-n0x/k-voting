<?php $__env->startSection('wrapper'); ?>
<div class="navbar py-1 px-5 w-full md:flex flex-row justify-between items-center bg-white">
    <div class="logo flex flex-row items-center gap-2 py-5 px-10">
        <img src="<?php echo e(asset('logo.png')); ?>" alt="K-PIRA" width="55" height="55">
        <p class="text-md font-bold text-gray-900">Komisi Pemilihan Raya</p>
    </div>
    <div class="menu -ml-24">
        <div class="flex flex-row gap-5">
            <a href="<?php echo e(route('privileged_admin')); ?>" class="font-semibold hover:text-red-500">Dashboard</a>
            <a href=<?php echo e(route('privileged_admin/dlm')); ?> class="font-semibold hover:text-red-500">Calon DLM</a>
            <a href=<?php echo e(route('privileged_admin/capresma')); ?> class="font-semibold hover:text-red-500">Capresma & Cawapresma</a>
        </div>
    </div>
    <div class="logout px-10">
        <a href="<?php echo e(url('/auth/logout')); ?>" class="text-lg font-semibold text-gray-900">Hi, <?php echo e(ucfirst(strtolower(session('name')))); ?></a>
        

    </div>
</div>

<?php echo $__env->yieldContent('body'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project-External\k_voting\resources\views/layout/user/u_master.blade.php ENDPATH**/ ?>